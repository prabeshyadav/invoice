"""choices for customer type"""
CUSTOMER_CHOICES = (
        ('business', 'business'),
        ('individual', 'individual'),
    )

"""choice for currency types"""

CURRENCY_CHOICES=(('NPR-Nepales','NPR-Nepales'),
                    ('AUD','AUD'),
                    ('CAD','CAD'),
                    ('CNI','CNI'))
LANGUAGE_CHOICES=(
    ('ENGLISH','ENGLISH'),
    ('NEPALI','NEPALI'),
)

SALUTATION_CHOICES=(
    ('Mr.','Mr.'),
    ('Mrs.','Mrs.'),
    ('Miss.','Miss.'),
    ('Ms.','Ms.'),
    ('Dr.','Dr.'),
)

ITEM_CHOICES=(
    ('Goods','Goods'),
    ('Services','Services')
)